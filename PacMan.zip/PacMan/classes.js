class Board {
    constructor(arr) {
        this.array = arr
    }
}

class Man {
    constructor() {
        this.x = [(canvas.width -1) / 2 - 25, (canvas.width -1) / 2 + 25] // ODD NUMBER SO -1 TO MAKE IT EVEN
        this.y = [975, 975 + 50]

        this.image = pacRight

        this.score = 0

    }

    move(dir) {
        let failed = false

        switch (dir) {


            case 'up':
                for (let i = this.x[0]; i <= this.x[1]; ++i) {

                    if (!checkTransparentBoard( i, this.y[0])) {
                        failed = true
                    }
                    
                }
                if (!failed) {
                    this.y[0] -= 4
                    this.y[1] -= 4
                }
                else{
                    //this.y[0] += 4
                    //this.y[1] += 4 
                }
                break

            case 'down':
                for (let i = this.x[0]; i <= this.x[1]; ++i) {
                    if (!checkTransparentBoard(i , this.y[1])) {
                        failed = true
                    }
                    
                }
                if (!failed) {
                    this.y[0] += 4
                    this.y[1] += 4

                }
                else {
                    //this.y[0] -= 4
                    //this.y[1] -= 4
                }
                break

            case 'left':

                
                if (this.x[0] - 5 < 0) {
                    this.x[0] = 1200 - 50
                    this.x[1] = 1200
                    return
                }


                for (let i = this.y[0]; i <= this.y[1]; ++i) {
                    if (!checkTransparentBoard(this.x[0], i )) {
                        failed = true
                    }
                    
                }
                if (!failed) {
                    this.x[0] -= 4
                    this.x[1] -= 4
                }
                else {
                    //this.x[0] += 4
                    //this.x[1] += 4
                }
                break

            case 'right':

                if (this.x[1] + 5 > 1200) {
                    this.x[0] = 0
                    this.x[1] = 50
                    return
                }




                for (let i = this.y[0]; i <= this.y[1]; ++i) {
                    if (!checkTransparentBoard(this.x[1], i )) {
                        failed = true
                    }
                    
                }
                if (!failed) {
                    this.x[0] += 4
                    this.x[1] += 4
                }
                // push it back out a bit
                else {
                    //this.x[0] -= 4
                    //this.x[1] -= 4
                }
                break      
        }
    }

    draw() {
        c.drawImage(this.image, this.x[0], this.y[0], 50, 50)
    }


}

class Point {
    constructor(x, y, prev) {
        this.x = x
        this.y = y
        this.prev = prev
    }
}

class Cherry {
    constructor(x, y) {
        this.x = x
        this.y = y
        this.eaten = false
    }

    draw() {
        if (!this.eaten) {
            c.drawImage(cherry, this.x, this.y, 50, 50)
        }
    }

    checkEat() {

        if (this.eaten) {
            return
        }

        if (player.x[0] < this.x && player.x[1] > this.x && player.y[0] < this.y + 25 && player.y[1] > this.y - 25) {
            console.log('eaten')
            this.eaten = true
            player.score += 1
        }
    }

}

class Ghost {
    constructor(color) {
        this.color = color // pink blue red

        this.y = 491
        this.x = 600
        this.moving = 'left'

        this.hitDecision = 0

        this.queue = []
        this.bfsFrames = 0

        this.arr = []

        this.active = false

        switch (this.color) {
            case 'red':
                this.image = red
                break
            case 'blue':
                this.image = blue
                break
            case 'gold':
                this.image = gold
                break
        }

    }

    draw() {
        c.drawImage(this.image, this.x - 35, this.y - 35, 70, 70)

    }

    checkCollide() {

        if (!this.active) {
            return
        }


        if (player.x[0] < this.x && player.x[1] > this.x && player.y[0] < this.y && player.y[1] > this.y) {
            state = 'game over'
            drawScreen(state, player.score)
            return
        }



    }


    updateGold() {

        if (this.bfsFrames != 0) {
            this.bfsFrames -= 1
            return
        }

        this.bfsFrames = 500

        let BFSarray = []

        for (let i = 0; i < path.length; ++i) {
            let slice = []
            for (let j = 0; j < path[i].length; ++j) {


                // might be (i, j) instead
                if (checkTransparent(i, j)) {
                    slice.push(true)
                }
                else {
                    slice.push(false)
                }
            }

            BFSarray.push(slice)

        }


        let q = []

        let pLoc = [0, 0] // row, column
        for (let i = 0; i < 50; ++i) {


            if (checkTransparent(player.x[0] + 25, player.y[0] + i)) {

                // 1007, 600
                pLoc = [player.y[0] + i, player.x[0] + 25]

            }


        }
        for (let i = 0; i < 50; ++i) {


            if (checkTransparent(player.x[0] + i, player.y[0] + 25)) {

                // 1007, 600
                pLoc = [player.y[0] + 25, player.x[0] + i]

            }


        }
        let gLoc = [this.y, this.x]




        q.push(new Point(gLoc[1], gLoc[0], 'null'))

        BFSarray[gLoc[1]][gLoc[0]] = false

        while (q.length != 0) {

            let point = q[0]
            q.shift()

           

            if (point.x == pLoc[1] && point.y == pLoc[0]) {

                return point
            }

            // switch em
            // not sure if -1 or [... - 1]

            if (point.x -1 >= 0 && BFSarray[point.x - 1][point.y] == true ) {
                q.push(new Point(point.x - 1, point.y, point))
                BFSarray[point.x - 1][point.y] = false

            }

            if (point.x + 1 <= 1200 && BFSarray[point.x + 1][point.y] == true ) {
                q.push(new Point(point.x + 1, point.y, point))
                BFSarray[point.x + 1][point.y] = false

            }

            if (point.y -1 >= 0 && BFSarray[point.x][point.y - 1] == true ) {
                q.push(new Point(point.x, point.y - 1, point))
                BFSarray[point.x][point.y - 1] = false

            }

            if (point.y + 1 <= 1320 && BFSarray[point.x][point.y + 1] == true ) {
                q.push(new Point(point.x, point.y + 1, point))
                BFSarray[point.x][point.y + 1] = false

            }


        }








        // point works
        //console.log(BFSarray[pLoc[1]][pLoc[0]])
        // starts at 1007, 600





    }





    update() {




        /*

        console.log('here123')
        // or this.color
        if (this.image == gold) {

            if (this.bfsFrames != 1000) {
                this.bfsFrames += 1
                return
            }


            this.bfsFrames = 0
            
            let q = []

            q.push([[this.y, this.x], 'null'])

            var dict = {

            }

            while (q.length != 0) {

                console.log('here')
                let cur = q.pop()

                console.log(cur)

                console.log(q.length)

                if (typeof dict[cur[0].toString()] == 'undefined') {
                    console.log('REACHED321')
                }

                dict[cur[0].toString()] = true

                



                // need to use cur for this stuff
                if ((cur[0][0] > player.y[0] && cur[0][0] < player.y[1]) && (cur[0][1] > player.x[0] && cur[0][1] < player.x[1])) {
                    console.log(cur[0][0], cur[0][1])
                    console.log(q)
                }


                // SCREWED UP SWITCH ALL OF THE AXIS X AND Y Y AND X

                console.log(cur[0][0], cur[0][1])

                console.log(checkTransparent(599, 491))

                if (checkTransparent(cur[0][1] + 1, cur[0][0])) {
                    console.log('here1')
                    q.push([[cur[0][0] + 1, cur[0][1]], cur])
                }

                if (checkTransparent(cur[0][1] - 1, cur[0][0])) {
                    console.log('here2')
                    q.push([[cur[0][0] - 1, cur[0][1]], cur])
                }

                if (checkTransparent(cur[0][1], cur[0][0] + 1)) {
                    console.log('here3')
                    q.push([[cur[0][0], cur[0][1] + 1], cur])
                }

                if (checkTransparent(cur[0][1], cur[0][0] - 1)) {
                    console.log('here4')
                    q.push([[cur[0][0], cur[0][1] - 1], cur])
                }





            }

            return


        }

        */


        this.hitDecision -= 1 // change hitdecision to get assigned to 2
        



        if (this.moving == 'left') {

            if (this.x - 5 < 0) {
                this.x + 5
                this.moving = 'right'
                console.log('reached1')
                return
            }



            
            if (this.hitDecision < 0) {
                for (let i = -4; i < 8; ++i) {
                    if (checkTransparent(this.x + i, this.y - 1) || checkTransparent(this.x + i, this.y + 1)) {
                        this.x += i
                        this.moving = 'null'
                        return
                    }
                }
            }
            

            if (checkTransparent(this.x - 3, this.y)) {
             
                this.x -= 3
            }
            else {
                
                this.x -= 3
                while (!checkTransparent(this.x , this.y)) {
                    this.x += 1
                }
                
                this.moving = 'null'
                return
            }
        }

        if (this.moving == 'right') {

            if (this.x + 5 > 1201) {
                this.x - 5
                this.moving = 'left'
                console.log('reached2')
                return
            }
            
            if (this.hitDecision < 0) {
                for (let i = -4; i < 8; ++i) {
                    if (checkTransparent(this.x + i, this.y - 1) || checkTransparent(this.x + i, this.y + 1)) {
                        this.x += i
                        this.moving = 'null'
                        return
                    }
                }
            }
            

            if (checkTransparent(this.x + 3, this.y)) {
                this.x += 3
            }

            else {
                
                this.x += 3
                while (!checkTransparent(this.x , this.y)) {
                    this.x -= 1
                }
                
                this.moving = 'null'
                return // just now adding returns
            }
        }

        if (this.moving == 'down') {

            
            if (this.hitDecision < 0) {
                for (let i = -4; i < 8; ++i) {
                    if (checkTransparent(this.x - 1, this.y + i) || checkTransparent(this.x + 1, this.y + i)) {
                        this.y += i
                        this.moving = 'null'
                        return
                    }
                }
            }
            




            if (checkTransparent(this.x, this.y + 3)) {
                this.y += 3
            }

            else {
                
                this.y += 3
                while (!checkTransparent(this.x , this.y)) {
                    this.y -= 1
                }
                
                this.moving = 'null'
                return
            }
        }

        if (this.moving == 'up') {

            
            if (this.hitDecision < 0) {
                for (let i = -4; i < 8; ++i) {
                    if (checkTransparent(this.x - 1, this.y + i) || checkTransparent(this.x + 1, this.y + i)) {
                        this.y += i
                        this.moving = 'null'
                        return
                    }
                }
            }
            



            if (checkTransparent(this.x, this.y - 3)) {
                this.y -= 3
            }

            else {
                
                this.y -= 3
                while (!checkTransparent(this.x , this.y)) {
                    this.y += 1
                }
                
                this.moving = 'null'
                return
            }
        }



        if (this.moving == 'null') { // and if blue
                    

            let uPossible = false
            let dPossible = false
            let lPossible = false
            let rPossible = false
    
            if (this.x != 0 && checkTransparent(this.x -1, this.y)) {
                lPossible = true
            }
    
            if (this.x != 1200 && checkTransparent(this.x +1, this.y)) {
                rPossible = true
            }
    
            if (this.y != 0 && checkTransparent(this.x, this.y -1)) {
                uPossible = true
            }
    
            if (this.y != 1328 && (checkTransparent(this.x, this.y + 1))) {
                dPossible = true
            }
    
            let options = []
    
            if (uPossible) {
                options.push('up')
            }
            if (dPossible) {
                options.push('down')
            }
            if (lPossible) {
                options.push('left')
            }
            if (rPossible) {
                options.push('right')
            }

            switch (this.color) {
                case 'blue':

                    // add a walk back feature if goes off course DONE
                    // wall bump
            
                    // probably change the switch case to be here
                    let contender = options[Math.floor(Math.random() * options.length)];
                    this.moving = contender
                    this.hitDecision = 3


                    return
                
                
                case 'red':
                    
                    this.hitDecision = 3

                    let rScore = this.x - (player.x[1] - 25)
                    let lScore = (player.x[1] - 25) - this.x
                    let dScore = this.y - (player.y[1] - 25)
                    let uScore = (player.y[1] - 25) - this.y

                    var numArray = [rScore,  lScore, dScore,  uScore];
                    numArray.sort(function(a, b) {
                        return a - b;
                    });

                    let newArray = []
                    for (let i = 0; i < numArray.length; ++i) {
                        if (numArray[i] == rScore) {
                            newArray.push(['rScore', rScore])
                        }
                        if (numArray[i] == lScore) {
                            newArray.push(['lScore', lScore])
                        }

                        if (numArray[i] == dScore) {
                            newArray.push(['dScore', dScore])
                        }
                        if (numArray[i] == uScore) {
                            newArray.push(['uScore', uScore])
                        }

                    }

                    // TRY REVERSING
                    newArray = newArray.reverse()


                    for (let i = 3; i >= 0; --i) {
                        if (newArray[i][0] == 'rScore' && rPossible) {
                            this.moving = 'right'
                            return
                        }
                        if (newArray[i][0] == 'lScore' && lPossible) {
                            this.moving = 'left'
                            return
                        }
                        if (newArray[i][0] == 'dScore' && dPossible) {
                            this.moving = 'down'
                            return
                        }
                        if (newArray[i][0] == 'uScore' && uPossible) {
                            this.moving = 'up'
                            return
                        }
                    }
                    return


                case 'gold':
                    break




            }



        }
    }
}