const board = new Image()
board.src = './img/pacman.png'

const man = new Image()
man.src = './img/man.png'

const pathImg = new Image()
pathImg.src ='./img/paths.png'

const red = new Image()
red.src = './img/red.png'

const blue = new Image()
blue.src = './img/blue.png'

const pink = new Image()
pink.src = './img/pink.png'

const gold = new Image()
gold.src = './img/gold.png'

const pacLeft = new Image()
pacLeft.src = './img/pacLeft.png'

const pacRight = new Image()
pacRight.src = './img/pacRight.png'

const pacDown = new Image()
pacDown.src = './img/pacDown.png'

const pacUp = new Image()
pacUp.src = './img/pacUp.png'

const cherry = new Image()
cherry.src = './img/cherry.png'