// Prelim
const canvas = document.querySelector('canvas')
//const c = canvas.getContext('2d', {willReadFrequently: true})
const c = canvas.getContext('2d')
// possibly change to 576 or whatever
canvas.width = 1201
canvas.height = 1328
c.fillStyle = 'white'
c.fillRect(0, 0, canvas.width, canvas.height)

// from https://www.delftstack.com/howto/javascript/javascript-random-number-between/#:~:text=Generate%20a%20Random%20Number%20Between%20Two%20Numbers%20in,is%20a%20random%20number%20between%20min%20and%20max.
function generateRandomInt(min,max){
    return Math.floor((Math.random() * (max-min)) +min);
}

/*
console.log('test yo')
console.log(path)


// just drawing
for (let i = 0; i < path.length; ++i) {
	for (let j = 0; j < path[i].length; ++j) {

		if (checkTransparent(i, j)) {
			c.fillStyle = 'red'
			c.fillRect(i, j, 1, 1)
		}

	}
}

//240
//491

for (let i = 0; i < path.length; ++i) {

	if (checkTransparent(600, i)) {
		console.log(i)
	}


}
*/

let bGhost = new Ghost('blue')
let rGhost = new Ghost('red')
//rGhost.moving = 'null'

let gGhost = new Ghost('gold')

let player = new Man()

let tlCherry = new Cherry(50, 50)
let trCherry = new Cherry(canvas.width - 100, 50)
let blCherry = new Cherry(50, 1200)
//let brCherry = new Cherry(canvas.width - 150, 1200)


bGhost.draw()
//c.drawImage(blue, 0, 0, 400, 400)

let wPressed = false
let sPressed = false
let aPressed = false
let dPressed = false

let frames = 0

function drawScreen(state, score) {

	if (state != 'game over') {
		return
	}

	// GAME OVER
	// GAME OVER
	// GAME OVER
	// GAME OVER
	// GAME OVER

	c.fillStyle = 'black'
	c.fillRect(0, 0, canvas.width, canvas.height)

	c.fillStyle = 'white'
	c.font = '50px arial'
	c.fillText(`Game ended with ${score} points`, canvas.width/2 - c.measureText(`Game ended with ${score} points`).width/2, canvas.height/2)
	return

}
let state = 'playing'
function animate() {
	frames += 1

	c.fillStyle = 'black'
	c.fillRect(0, 0, canvas.width, canvas.height)
	c.drawImage(board, 0, 0)
	/*
	//draw lines
	for (let i = 0; i < path.length; ++i) {
		for (let j = 0; j < path[i].length; ++j) {
	
			if (checkTransparent(i, j)) {
				c.fillStyle = 'red'
				c.fillRect(i, j, 1, 1)
			}
		}
	}
	*/
	

	if (wPressed) {
		player.move('up')
		player.image = pacUp
		
	}
	else if (sPressed) {
		player.move('down')
		player.image = pacDown
	}
	else if (aPressed) {
		player.move('left')
		player.image = pacLeft
	}

	else if (dPressed) {
		player.move('right')
		player.image = pacRight
	}

	player.draw()
	
	tlCherry.draw()
	trCherry.draw()
	blCherry.draw()
	//brCherry.draw()

	tlCherry.checkEat()
	trCherry.checkEat()
	blCherry.checkEat()
	//brCherry.checkEat()


	bGhost.draw()
	bGhost.update()
	bGhost.active = true


	// activate red
	if (frames > 2000) {
		rGhost.active = true
		rGhost.draw()
		rGhost.update()
	}

	
	if (frames > 1000) {

		gGhost.active = true

		let bfsPoint = gGhost.updateGold()

		if (typeof bfsPoint != 'undefined') {
	
			let p = bfsPoint.prev
	
			let travelArr = []
			
	
			while (p.prev != 'null') {

				travelArr.push([p.x, p.y])
				p = p.prev
	
			}
	
			travelArr = travelArr.reverse()
	
			gGhost.arr = travelArr

		}
	
		else {

			if (gGhost.arr.length == 0) {
				gGhost.bfsFrames = 0
			}

			else {
				gGhost.x = gGhost.arr[0][0]
				gGhost.y = gGhost.arr[0][1]
				gGhost.arr.shift()
			}

		}
	
		gGhost.draw()
	}
	


	bGhost.checkCollide()
	gGhost.checkCollide()
	rGhost.checkCollide()

	if (player.score == 3) {
		state = 'game over'
		drawScreen(state, player.score)
	}



	if (state == 'playing') {
		window.requestAnimationFrame(animate)
	}
	

}
animate()


//4th val is transparency. 0 is transparent 255 is not
/*
pathImg.onload = function() {

	let boardArray = []

	c.drawImage(pathImg, 0, 0, canvas.width, canvas.height)

	for (let i = 0; i < canvas.width; ++i) {
		let slice = []
		for (let j = 0; j < canvas.height; ++j) {
	
			
			slice.push(c.getImageData(i, j, 1, 1))
	
		}
	
		boardArray.push(slice)
	
	}

	let reached = false

	console.log('here')
	for (let i = 0; i < boardArray.length; ++i) {
		for (let j = 0; j < boardArray[i].length; ++j) {

			if (boardArray[i][j]['data'][3] == 0) {
				console.log(i, j)
				reached = true
				c.fillStyle = 'red'
				c.fillRect(i, j, 1, 1)
			}



		}
	}
	if (reached) {
		console.log(boardArray)
	}
	reached = false
	
	//fs.writeFileSync('./board.json', JSON.stringify(boardArray, null, 2) , 'utf-8');
	
	return boardArray

}
/*
var interval;
interval = setInterval(function () {

	let boardArray = pathImg.onload()

    if (typeof boardArray != 'undefined') {
        clearInterval(interval);

    }

}, 50) //check every 50 ms



console.log(boardArray)
*/


window.addEventListener('keydown', (e) => {

	switch(e.key) {

		case 'ArrowUp':
			if (sPressed) {
				break
			}
			wPressed = true
			break

		
		case 'ArrowDown':
			if (wPressed) {
				break
			}
			sPressed = true
			break

		case 'ArrowLeft':
			if (dPressed) {
				break
			}
			aPressed = true
			break

		case 'ArrowRight':
			if (aPressed) {
				break
			}
			dPressed = true
			break
	}

})


window.addEventListener('keyup', (e) => {

	switch(e.key) {

		case 'ArrowUp':

			wPressed = false
			break

		
		case 'ArrowDown':

			sPressed = false
			break

		case 'ArrowLeft':

			aPressed = false
			break

		case 'ArrowRight':

			dPressed = false
			break
	}


})