
function checkTransparent(y, x) {

    if (y > 1201 || y < 0) {
        return false
    }



    if (path[y][x]['data'][3] == 0) {
        return true
    }

    else {
        return false
    }

}

function checkTransparentBoard(y, x) {

    if (boardArray[y][x]['data'][3] == 0) {
        return true
    }

    else {
        return false
    }



}