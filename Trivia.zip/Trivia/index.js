// Prelim
const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1024
canvas.height = 576
c.fillStyle = 'maroon'
c.fillRect(0, 0, canvas.width, canvas.height)

// from https://www.delftstack.com/howto/javascript/javascript-random-number-between/#:~:text=Generate%20a%20Random%20Number%20Between%20Two%20Numbers%20in,is%20a%20random%20number%20between%20min%20and%20max.
function generateRandomInt(min,max){
    return Math.floor((Math.random() * (max-min)) +min);
}


function drawImage(ctx, image, x, y, w, h, degrees){
	ctx.save();
	ctx.translate(x+w/2, y+h/2);
	ctx.rotate(degrees*Math.PI/180.0);
	ctx.translate(-x-w/2, -y-h/2);
	ctx.drawImage(image, x, y, w, h);
	ctx.restore();
  }

//https://the-trivia-api.com/docs/
/*
fetch('https://the-trivia-api.com/api/questions?limit=1&region=US&difficulty=medium')
  .then((response) => response.json())
  .then((data) => console.log(data));
*/
var obj;

fetch('https://the-trivia-api.com/api/questions?limit=1&region=US&difficulty=medium')
.then(res => res.json())
.then(data => {
	obj = data;
	})
.then(() => {
	console.log(obj[0]);
	});

let leftScale = new Scale("left")
let rightScale = new Scale("right")
let game = new Game()

let leftPlayer = new Player()
let rightPlayer = new Player()



// waiting / question / answer
function statusScreen(total1, total2, curBet1, curBet2) {
	c.fillStyle = 'white'
	c.font = "30px arial"


	// GAME OVER
	// GAME OVER
	// GAME OVER
	// GAME OVER
	// GAME OVER
	
	if (game.match == 2) {
		c.fillStyle = '#014421'
		c.fillRect(0, 0, canvas.width, canvas.height)

		c.fillStyle = 'white'
		c.fillText('Game Over!', canvas.width/2 - c.measureText('Game Over!').width/2, 100)
		if (total1 == total2) {
			c.fillText(`Tie with ${total1} Points!`, canvas.width/2 - c.measureText(`Tie with ${total1} Points!`).width/2, 150)
		}

		else if (total1 > total2) {
			c.fillText(`Left player wins with a total of ${total1} Points!`, canvas.width/2 - c.measureText(`Left player wins with a total of ${total1} Points!`).width/2, 150)
		}

		else {
			c.fillText(`Right player wins with a total of ${total2} Points!`, canvas.width/2 - c.measureText(`Right player wins with a total of ${total1} Points!`).width/2, 150)
		}

		return
	}

	switch (game.state) {

		case 'waiting':
			
			console.log('waiting')

			leftScale = new Scale("left")
			rightScale = new Scale("right")

			c.fillText(`New question will appear in ${parseInt(game.questionFrames / 60)}`, canvas.width/2 - 200, 100)
			break


		case 'question':
			console.log(game.state)
			let line1 = ''
			let line2 = ''
			let newLine = false
			for (let i = 0; i < obj[0]['question'].length; ++i) {
				if (i > 65 && obj[0]['question'][i] == " ") {
					newLine = true
				}
				if (newLine) {
					line2 += obj[0]['question'][i]
				}
				else {
					line1 += obj[0]['question'][i]
				}
			}
			c.fillText(` ${line1}`, 0, 30)
			c.fillText(` ${line2}`, 0, 60)
			let contender = obj[0]['incorrectAnswers'][Math.floor(Math.random()*obj[0]['incorrectAnswers'].length)]
			//let answer = obj[0]['correctAnswer']
			if (!game.orderFound) {
				if (generateRandomInt(1, 3) == 1) {
					game.left = obj[0]['correctAnswer']
					game.right = contender
				}
				else {
					game.right = obj[0]['correctAnswer']
					game.left = contender
				}
				game.orderFound = true
			}
			c.fillStyle = '#2D68C4'
			c.fillText(`${game.left}`, canvas.width/2 - c.measureText(game.left).width / 2, 100)
			c.fillStyle = 'white'
			c.fillText(`or`, canvas.width/2 - c.measureText('or').width/2, 140)
			c.fillStyle = '#DF4661'
			c.fillText(`${game.right}`, canvas.width/2 - c.measureText(game.right).width / 2, 180)
			c.fillStyle = 'white'
			
			

			if (game.questionUpFrames > 200) {
				c.fillText(parseInt((game.questionUpFrames - 200) / 60), canvas.width/2 - 13, 500)

			}


			if (game.questionUpFrames == 200) {
				let addVal1 = 0
				let addVal2 = 0

				// if blue correct
				if (game.left == obj[0]['correctAnswer']) {

					if (curBet1 <= 0) {
						addVal1 = Math.abs(curBet1)
					}

					else {
						addVal1 = curBet1 * -1
					}

					if (curBet2 <= 0) {
						addVal2 = Math.abs(curBet2)
					}

					else {
						addVal2 = curBet2 * -1
					}

				
				}

				else {

					if (curBet1 <= 0) {
						addVal1 = curBet1
					}

					else {
						addVal1 = curBet1
					}

					if (curBet2 <= 0) {
						addVal2 = curBet2
					}

					else {
						addVal2 = curBet2
					}


				}



				leftPlayer.total += addVal1
				rightPlayer.total += addVal2


			}







			if (game.questionUpFrames < 200) {

				if (game.left == obj[0]['correctAnswer']) {
					c.drawImage(checkmark, canvas.width/2 - c.measureText(game.left).width / 2 + c.measureText(game.left).width, 50, 50, 50)
				}

				else {
					c.drawImage(checkmark, canvas.width/2 - c.measureText(game.right).width / 2 + c.measureText(game.right).width, 130, 50, 50)
				}


			}


			console.log(game.questionUpFrames)
			if (game.questionUpFrames == 0) {

				
				
				fetch('https://the-trivia-api.com/api/questions?limit=1&region=US&difficulty=medium')
				.then(res => res.json())
				.then(data => {
					obj = data;
					});


				game.state = 'waiting'
				game.questionFrames = 180
				game.questionUpFrames = 1000
				game.question = 'null'
				game.state = 'waiting' // waiting / question / answered
				game.orderFound = false
				game.left = 'null'
				game.right = 'null'
				game.showAnswer = false

				leftPlayer.curBet = 0
				rightPlayer.curBet = 0

				
				game.match += 1
				break
			}

		
		break

	}	



	c.fillStyle = 'white'
	c.fillText(`Current Bet: `, 30, 535 )
	if (curBet1 > 0) {
		c.fillStyle = '#DF4661'
	}
	if (curBet1 < 0) {
		c.fillStyle = '#2D68C4'
	}
	if (curBet1 == 0) {
		c.fillStyle = 'white'
	}
	c.fillText(`${Math.abs(curBet1)}`, 30 + c.measureText(`Current Bet: `).width, 535 )
	c.fillStyle = 'white'
	c.fillText(`Total: ${total1}`, 300, 535 )
	c.fillStyle = 'white'
	c.fillText(`Current Bet: `, 30 + canvas.width/2, 535 )
	if (curBet2 > 0) {
		c.fillStyle = '#DF4661'
	}
	if (curBet2 < 0) {
		c.fillStyle = '#2D68C4'
	}
	if (curBet2 == 0) {
		c.fillStyle = 'white'
	}
	c.fillText(`${Math.abs(curBet2)}`, 30 + c.measureText(`Current Bet: `).width + canvas.width/2, 535 )
	c.fillStyle = 'white'
	c.fillText(`Total: ${total2}`, 300 + canvas.width/2, 535 )


	







	
}



function animate() {

	c.fillStyle = '#014421'
	c.fillRect(0, 0, canvas.width, canvas.height)
	/*
	// NOTICE NOT USING .C
	//base 258 x 409
	//topbar
	//364 x 59
	//weight
	// 179 x 310
	//                 x, y, w, h, degree
	//drawImage(c, base, 125, 260, 150, 200, 0)
	//drawImage(c, topbar, 50, 210, 300, 50, 0)
	//drawImage(c, weight, 20, 250, 179 / 2, 310 / 2, 0)
	//drawImage(c, base, 125, 260, 150, 200, 0)
	//drawImage(c, topbar, 50, 210, 300, 50, 0) // 0->10 bar / 250 -> 225 weight change 1 change 2.5
												// 0 -> -20 / 250 -> 295 AND x 20 -> 30
	// left weight
	//drawImage(c, weight, 20, 250, 179 / 2, 310 / 2, 0)
	// Right weight
	//drawImage(c, weight, 292, 250, 179 / 2, 310 / 2, 0)
	*/
	leftScale.draw()
	rightScale.draw()

	c.drawImage(gradient, 0, 550, canvas.width / 2, 50)
	c.drawImage(gradient, canvas.width/2, 550, canvas.width / 2, 60)
	c.fillStyle = 'black'
	c.fillRect(0, 540, canvas.width, 10)
	c.fillRect(canvas.width/2 - 5, 500, 10, 100)

	c.fillRect(0, 500, canvas.width, 10)

	leftScale.containerUpdate()
	rightScale.containerUpdate()

	statusScreen(leftPlayer.total, rightPlayer.total, leftPlayer.curBet, rightPlayer.curBet)

	game.update()
	window.requestAnimationFrame(animate)

}
animate()













window.addEventListener('keydown', (e) => {

	// switch case doesn't work for multiple inputs

	if (game.state == 'waiting') {
		return
	}

	switch(e.key) {

		case 'd':
			if (leftScale.value == 30) {
				break
			}


			leftScale.lShift()
			leftScale.value += 1
			leftPlayer.curBet += 1

			break

		case 'a':
			if (leftScale.value == -30) {
				break
			}

			leftScale.rShift()
			leftScale.value -= 1
			leftPlayer.curBet -= 1
			break


			case 'ArrowRight':
				if (rightScale.value == 30) {
					break
				}
	
	
				rightScale.lShift()
				rightScale.value += 1
				rightPlayer.curBet += 1
				break
	
			case 'ArrowLeft':
				if (rightScale.value == -30) {
					break
				}
	
				rightScale.rShift()
				rightScale.value -= 1

				rightPlayer.curBet -= 1
				break









	}


})