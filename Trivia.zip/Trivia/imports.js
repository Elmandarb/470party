//Imports
const coin1 = new Image()
coin1.src = './img/1coin.png'
// rename these
const coin2 = new Image()
coin2.src = './img/2coins.png'
const coin3 = new Image()
coin3.src = './img/3coins.png'

const base = new Image()
base.src = './img/base.png'

const weight = new Image()
weight.src = './img/weight.png'

const topbar = new Image()
topbar.src = './img/topbar.png'

const gradient = new Image()
gradient.src ='./img/gradient.png'

const checkmark = new Image()
checkmark.src = './img/checkmark.png'