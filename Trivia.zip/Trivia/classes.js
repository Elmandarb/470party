

class Player {
    constructor() {
        this.curBet = 0
        this.total = 0

    }



}

class Game {
    constructor() {
        this.questionFrames = 180
        this.questionUpFrames = 1000
        this.question = 'null'
        this.state = 'waiting' // waiting / question / answered
        this.orderFound = false
        this.left = 'null'
        this.right = 'null'
        this.showAnswer = false
        this.match = 0

    }

    update() {

        switch (this.state) {
            case 'waiting':
                this.questionFrames -= 1
                
                if (this.questionFrames == 0) {
                    this.state = 'question'
                    this.questionFrames = 180
                }
                break

            case 'question':

                this.questionUpFrames -= 1
                /*
                if (this.questionUpFrames == 0) {
                    this.state = 'answer'
                    this.questionUpFrames = 1000
                }
                */
                break

        }


    }
}

class Scale {
    //position is "left" or "right"
    constructor(position) {
        this.pos = position
        let addVal = 40

        this.rotation = 0
        this.topBarRotation = 0
        this.leftWeightY = 250
        this.leftWeightX = 20 + addVal

        this.rightWeightY = 250
        this.rightWeightX = 292 + addVal

        this.topBarX = 50 + addVal

        this.baseX = 125 + addVal

        this.value = 0
        

        this.containerL = 'null'

        this.containerR = 'null'

        switch (this.pos) {
            
            // only need a case that changes for right
            case 'right':
                console.log('reached123')
                let addVal = 40

                this.rotation = 0
                this.topBarRotation = 0
                this.leftWeightY = 250
                this.leftWeightX = 20 + addVal + canvas.width/2
        
                this.rightWeightY = 250
                this.rightWeightX = 292 + addVal + canvas.width/2
        
                this.topBarX = 50 + addVal + canvas.width/2
        
                this.baseX = 125 + addVal + canvas.width/2
        
                this.value = 0

        }








    }
// 0->10 bar / 250 -> 225 weight change 1 change 2.5
// 0 -> -20 / 250 -> 295 AND x 20 -> 30

    containerUpdate() {

        let v = this.value

        if (v > 0 && v < 10) {

            this.containerR = coin1
            this.containerL = 'null'
        }

        else if (v >= 10 && v < 20) {

            this.containerR = coin2

        }

        else if (v >= 20) {

            this.containerR = coin3

        }


        else if (v < 0 && v > -10) {
            this.containerL = coin1
            this.containerR = 'null'
        }

        else if (v <= -10 && v > -20) {
            this.containerL = coin2
            this.containerR = 'null'
        }

        else if (v <= -20) {
            this.containerL = coin3
            this.containerR = 'null'
        }

    }

    lShift() {


        this.topBarRotation += 1

        this.leftWeightY -= 2.5

        this.rightWeightY += 2.25

        //this.rightWeightX -= 0.5

        
        
    }

    
    rShift() {


        this.topBarRotation -= 1

        this.rightWeightY -= 2.5

        this.leftWeightY += 2.25

        //this.leftWeightX += 0.5

        
        
    }


    draw() {
	//                     x, y, w, h, degree

        //base x = 125

        drawImage(c, base, this.baseX, 260, 150, 200, 0)

	    drawImage(c, topbar, this.topBarX, 210, 300, 50, this.topBarRotation)

        // left weight
	    drawImage(c, weight, this.leftWeightX, this.leftWeightY, 90, 155, 0)

        // right weight
        drawImage(c, weight, this.rightWeightX, this.rightWeightY, 90, 155, 0)

        switch (this.containerL) {
            case 'null':
                break
            case coin1:
                drawImage(c, this.containerL, this.leftWeightX + 25, this.leftWeightY + 110, 30, 30, 0)
                break
            case coin2:
                drawImage(c, this.containerL, this.leftWeightX + 5, this.leftWeightY + 100, 80, 60, 0)
                break
            case coin3:
                drawImage(c, this.containerL, this.leftWeightX + 10, this.leftWeightY + 70, 80, 80, 0)
                break
        }

        switch (this.containerR) {
            case 'null':
                break
            case coin1:
                drawImage(c, this.containerR, this.rightWeightX + 25, this.rightWeightY + 110, 30, 30, 0)
                break
            case coin2:
                drawImage(c, this.containerR, this.rightWeightX + 5, this.rightWeightY + 100, 80, 60, 0)
                break
            case coin3:
                drawImage(c, this.containerR, this.rightWeightX + 10, this.rightWeightY + 70, 80, 80, 0)
                break
        }




    }



}
