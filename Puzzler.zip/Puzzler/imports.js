//Imports
const redL = new Image()
redL.src = './img/redL.png'
const redR = new Image()
redR.src = './img/redR.png'
const redU = new Image()
redU.src = './img/redU.png'
const redD = new Image()
redD.src = './img/redD.png'

const greenL = new Image()
greenL.src = './img/greenL.png'
const greenR = new Image()
greenR.src = './img/greenR.png'
const greenU = new Image()
greenU.src = './img/greenU.png'
const greenD = new Image()
greenD.src = './img/greenD.png'

const blueL = new Image()
blueL.src = './img/blueL.png'
const blueR = new Image()
blueR.src = './img/blueR.png'
const blueU = new Image()
blueU.src = './img/blueU.png'
const blueD = new Image()
blueD.src = './img/blueD.png'

const redB = new Image()
redB.src = './img/redB.png'

const greenB = new Image()
greenB.src = './img/greenB.png'

const blueB = new Image()
blueB.src = './img/blueB.png'